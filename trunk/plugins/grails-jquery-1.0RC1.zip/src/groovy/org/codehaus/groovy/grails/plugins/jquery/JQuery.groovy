package org.codehaus.groovy.grails.plugins.jquery
/**
 *
 * @author craigjones Jul 16, 2008
 */
class JQuery {

    // TODO: I put this const here to emulate the YUI plugin, but this same version number is specified in 3 other places (JQueryGrailsPlugin.groovy, plugin.xml, _Install.groovy).  Surely, there's a way to get at one of them, rather that stating it a 4th time here.
    static version = "1.2.6"

}
